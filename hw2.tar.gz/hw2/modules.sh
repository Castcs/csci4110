module unload intel
module load gcc
module load openmpi
